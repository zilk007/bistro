(function() {
  $.fn.serializeObject = function() {
    var o, obj, _i, _len, _ref;
    obj = {};
    _ref = this.serializeArray();
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      o = _ref[_i];
      obj[o.name] = o.value;
    }
    return obj;
  };

}).call(this);
